package com.push.notification.config;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

@Configuration
public class FCMconfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(FCMconfig.class);

    @Value("${app.firebase-configuration-file}")
    private String fireBaseConfig;

    @Bean
    public FirebaseApp initializeFirebaseApp() throws IOException {
        GoogleCredentials credentials;

        try {
            LOGGER.info("Initializing Firebase with configuration file: {}", fireBaseConfig);

            ClassPathResource resource = new ClassPathResource(fireBaseConfig);
            credentials = GoogleCredentials.fromStream(resource.getInputStream());

            FirebaseOptions options = new FirebaseOptions.Builder()
                .setCredentials(credentials)
                .build();

            return FirebaseApp.initializeApp(options);

        } catch (IOException e) {
            LOGGER.error("Failed to initialize Firebase", e);
            throw e; 
        }
    }
}
