package com.push.notification.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import com.push.notification.entity.User;

@Service
public class UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);

    public String sendNotification(User user) {
        String response = null;

        // Extract the part of the URL after the fifth '/'
        String processedUrl = extractUrlPart(user.getMessage());

        // Create the notification with the extracted URL part
        Notification notification = Notification.builder()
                .setTitle(user.getTitle())
                .setBody(processedUrl) // Only the extracted URL part is included
                .build();

        Message message = Message.builder()
                .setToken(user.getToken())
                .setNotification(notification)
                .build();

        try {
            response = FirebaseMessaging.getInstance().send(message);
            LOGGER.info("Notification sent successfully. Response: " + response);
        } catch (FirebaseMessagingException e) {
            LOGGER.error("Failed to send notification. Error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            LOGGER.error("An unexpected error occurred while sending notification", e);
            e.printStackTrace();
        }

        return response;
    }

    private String extractUrlPart(String url) {
        // Split the URL by '/'
        String[] parts = url.split("/");

        // Check if there are at least six parts
        if (parts.length > 5) {
            StringBuilder remainingUrl = new StringBuilder();
            for (int i = 5; i < parts.length; i++) {
                if (i > 5) {
                    remainingUrl.append('/');
                }
                remainingUrl.append(parts[i]);
            }
            return remainingUrl.toString();
        } else {
            return "Invalid URL";
        }
    }
}
